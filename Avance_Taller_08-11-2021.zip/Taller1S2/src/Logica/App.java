package Logica;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class App {
	public static void main(String[] args) throws IOException {
		Sistema sistema = new SistemaImpl();
		Carga_Personajes(sistema);
		Carga_Cuentas(sistema);
		Carga_Recaudaciones(sistema);
		sistema.iniciar_sesion();
		Guardar_Personajes(sistema);
		Guardar_Cuentas(sistema);
		Guardar_Estadisticas(sistema);
	}
	public static void Carga_Personajes(Sistema sistema) throws IOException {
		File archivo = new File ("src/Personajes.txt"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String nombre = partes[0];
			String rol = partes[1];
			int cantidadSkins = Integer.parseInt(partes[2]);
			for(int i=0;i<cantidadSkins;i++) {
				String nombreSkin = partes[i];
				String calidadSkin=partes[i];
				sistema.agregarSkins(nombreSkin.toLowerCase(),calidadSkin);
				sistema.asociarSkinPersonaje(nombre,nombreSkin);
			}
			sistema.agregarPersonaje(nombre.toLowerCase(),rol);
		}
		reader.close();
	}
	public static void Carga_Cuentas(Sistema sistema) throws IOException {
		File archivo = new File ("src/Cuentas.txt"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String nombrecuenta = partes[0];
			String password = partes[1];
			String nick = partes[2];
			int nivelcuenta = Integer.parseInt(partes[3]);
			int rpcuenta = Integer.parseInt(partes[4]);
			String region = partes[partes.length-1];
			sistema.agregarCuenta(nombrecuenta,password,nick,nivelcuenta,rpcuenta,region);
			int cantidadPersonajes = Integer.parseInt(partes[5]);
			int pos=6;
			for(int i=0;i<cantidadPersonajes;i++) {
				String nombrePersonaje = partes[pos++];
				sistema.asociarPersonajeCuenta(nombrecuenta, nombrePersonaje.toLowerCase());
				int cantidadSkins = Integer.parseInt(partes[pos++]);
				for(int j=0;j<cantidadSkins;j++) {
					String nombreSkins = partes[pos++];
					sistema.asociarSkinCuenta(nombrecuenta,nombreSkins.toLowerCase());
				}
			}
		}
		reader.close();
	}
	public static void Carga_Recaudaciones(Sistema sistema) throws IOException {
		File archivo = new File ("src/Estadisticas.txt"); 
		FileReader text = new FileReader (archivo); 
		BufferedReader reader = new BufferedReader(text); 
		String linea;
		String[] partes;
		int pos=0;
		while((linea = reader.readLine())!=null){
			partes = linea.split(",");
			String nombrepersonaje = partes[0];
			int recaudacion = Integer.parseInt(partes[1]);
			sistema.ingresarRecaudacion(nombrepersonaje.toLowerCase(), recaudacion,pos);     
			pos++;
		}
		reader.close();
	}
	public static void Guardar_Personajes(Sistema sistema) throws IOException {
		FileWriter fw = new FileWriter("src/Personajes1.txt");
		fw.write(sistema.StringPersonaje());
        fw.close();
	}
	public static void Guardar_Cuentas(Sistema sistema) throws IOException {
		FileWriter fw = new FileWriter("src/Cuentas1.txt");
		fw.write(sistema.StringCuenta());
        fw.close();
	}
	public static void Guardar_Estadisticas(Sistema sistema) throws IOException {
		FileWriter fw = new FileWriter("src/Estadistica1.txt");
		fw.write(sistema.StringEstadistica());
        fw.close();
	}
}
