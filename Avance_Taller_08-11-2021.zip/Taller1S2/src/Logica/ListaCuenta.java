package Logica;

import Dominio.Cuenta;

public class ListaCuenta {
	private Cuenta[] ListaCuenta;
	private int cont;
	private int max;
	public ListaCuenta(int max) {
		ListaCuenta = new Cuenta[max];
		cont = 0;
		this.max=max;
	}

	public boolean insertarCuenta(Cuenta cuenta) { 
		if (cont < max) {
			ListaCuenta[cont] = cuenta;
			cont++;
			return true;

		} else {
			return false;
		}

	}

	public Cuenta buscarNombre(String nombre) {
		int i;
		for (i = 0; i < cont; i++) {
			if (ListaCuenta[i].getNombreCuenta().equals(nombre)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} 
		else {
			return ListaCuenta[i];
		}
	}

	public Cuenta getCuentaI(int i) {
		if (i >= 0 && i < cont) {
			return ListaCuenta[i];

		} else {
			return null;
		}

	}
	public Cuenta[] getListaCuenta() {
		return ListaCuenta;
	}
	public void setListaCuenta(Cuenta[] ListaCuenta) {
		this.ListaCuenta = ListaCuenta;
	}
	public int getCont() {
		return cont;
	}
	public void setCont(int cont) {
		this.cont = cont;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	public void ordenar() {
		for(int i=cont-1;i>0;i--) {
			for(int j=0;j<i;j++) {
				if(ListaCuenta[j+1].getNivelCuenta()>ListaCuenta[j].getNivelCuenta()) {
					Cuenta temp=ListaCuenta[j];
					ListaCuenta[j]=ListaCuenta[j+1];
					ListaCuenta[j+1]=temp;
				}
			}
		}
	}
}
