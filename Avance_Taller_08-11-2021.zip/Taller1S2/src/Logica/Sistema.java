package Logica;


public interface Sistema {
	boolean agregarCuenta(String nombreCuenta,String password,String nick ,int nivelCuenta, int rp,String region);
	boolean agregarPersonaje(String nombre,String rol);
	boolean agregarSkins(String nombre,String calidad);
	void asociarSkinPersonaje(String nombre,String nombreSkins);
	void asociarSkinCuenta(String nombrecuenta,String nombreSkins);
	void asociarPersonajeCuenta(String nombrecuenta,String nombrePersonaje);
	void ingresarRecaudacion(String nombre,int recaudado,int pos);
	void nuevo_usuario(String nombre);
	int clasificar_nombre(String nombreclasificar);
	void iniciar_sesion();
	String StringPersonaje();
	String StringCuenta();
	String StringEstadistica();
	String Obtener();
}
