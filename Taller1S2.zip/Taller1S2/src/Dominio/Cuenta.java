package Dominio;

import Logica.ListaPersonaje;
import Logica.ListaSkins;

public class Cuenta {
	private String nombreCuenta;
	private String password;
	private String nick;
	private int nivelCuenta;
	private int rp;
	private String region;
	private ListaPersonaje personajes;
	private ListaSkins skins;
	
	public Cuenta(String nombreCuenta,String password,String nick ,int nivelCuenta, int rp,String region) {
		this.nombreCuenta = nombreCuenta;
		this.password=password;
		this.nick = nick;
		this.nivelCuenta = nivelCuenta;
		this.rp = rp;
		this.region = region;
		personajes = new ListaPersonaje(155);
		skins = new ListaSkins(1000);
	}

	public String getNombreCuenta() {
		return nombreCuenta;
	}

	public void setNombreCuenta(String nombreCuenta) {
		this.nombreCuenta = nombreCuenta;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public int getNivelCuenta() {
		return nivelCuenta;
	}

	public void setNivelCuenta(int nivelCuenta) {
		this.nivelCuenta = nivelCuenta;
	}

	public int getRp() {
		return rp;
	}

	public void setRp(int rp) {
		this.rp = rp;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public ListaPersonaje getPersonajes() {
		return personajes;
	}

	public void setPersonajes(ListaPersonaje personajes) {
		this.personajes = personajes;
	}

	public ListaSkins getSkins() {
		return skins;
	}

	public void setSkins(ListaSkins skins) {
		this.skins = skins;
	}
}
