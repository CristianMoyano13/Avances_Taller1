package Dominio;

import Logica.ListaSkins;

public class Personaje {
	private String nombre;
	private String rol;
	private int cantidadSkins;
	public ListaSkins skinsPersonaje;
	
	public Personaje(String nombre,String rol,int cantidadSkins) {
		this.nombre=nombre;
		this.rol=rol;
		this.cantidadSkins=cantidadSkins;
		skinsPersonaje= new ListaSkins(1000);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	public ListaSkins getSkinsPersonaje() {
		return skinsPersonaje;
	}

	public void setSkinsPersonaje(ListaSkins skinsPersonaje) {
		this.skinsPersonaje = skinsPersonaje;
	}
	public int getCantidadSkins() {
		return cantidadSkins;
	}

	public void setCantidadSkins(int cantidadSkins) {
		this.cantidadSkins = cantidadSkins;
	}

}
