package Logica;

import Dominio.*;

public class ListaPersonaje {
	private Personaje[] ListaPersonaje;
	private int cont;
	private int max;
	public ListaPersonaje(int max) {
		ListaPersonaje = new Personaje[max];
		cont = 0;
		this.max=max;
	}

	public boolean insertarPersonaje(Personaje Personaje) { 
		if (cont < max) {
			ListaPersonaje[cont] = Personaje;
			cont++;
			return true;

		} else {
			return false;
		}

	}

	public Personaje buscarNombre(String nombre) {
		int i;
		for (i = 0; i < cont; i++) {
			if (ListaPersonaje[i].getNombre().equalsIgnoreCase(nombre)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} else {
			return ListaPersonaje[i];
		}
	}

	public Personaje getPersonajeI(int i) {
		if (i >= 0 && i < cont) {
			return ListaPersonaje[i];

		} else {
			return null;
		}

	}
	public Personaje[] getListaPersonaje() {
		return ListaPersonaje;
	}
	public void setListaPersonaje(Personaje[] ListaPersonaje) {
		this.ListaPersonaje = ListaPersonaje;
	}
	public int getCont() {
		return cont;
	}
	public void setCont(int cont) {
		this.cont = cont;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
}
