package Logica;

import Dominio.Skins;

public class ListaSkins {
	private Skins[] ListaSkins;
	private int cont;
	private int max;
	public ListaSkins(int max) {
		ListaSkins = new Skins[max];
		cont = 0;
		this.max=max;
	}

	public boolean insertarSkins(Skins skins) { 
		if (cont < max) {
			ListaSkins[cont] = skins;
			cont++;
			return true;

		} else {
			return false;
		}

	}

	public Skins buscarNombre(String nombre) {
		int i;
		for (i = 0; i < cont; i++) {
			if (ListaSkins[i].getNombre().equals(nombre)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} else {
			return ListaSkins[i];
		}
	}

	public Skins getSkinsI(int i) {
		if (i >= 0 && i < cont) {
			return ListaSkins[i];

		} else {
			return null;
		}

	}
	public Skins[] getListaSkins() {
		return ListaSkins;
	}
	public void setListaSkins(Skins[] ListaSkins) {
		this.ListaSkins = ListaSkins;
	}
	public int getCont() {
		return cont;
	}
	public void setCont(int cont) {
		this.cont = cont;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
}
