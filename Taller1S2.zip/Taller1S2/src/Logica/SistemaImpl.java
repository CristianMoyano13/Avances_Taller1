package Logica;

import java.util.Scanner;

import Dominio.*;

public class SistemaImpl implements Sistema {
	private ListaCuenta ListaCuenta;
	private ListaSkins ListaSkins;
	private ListaPersonaje ListaPersonaje;
	String [] personaje = new String [155];
	int [] recaudacion = new int [155];
	int posicionrecaudacion=0;

	public SistemaImpl() {
		ListaCuenta= new ListaCuenta(1000);
		ListaSkins = new ListaSkins(1000);
		ListaPersonaje = new ListaPersonaje(155);
	}
	public void ingresarRecaudacion(String nombre,int recaudado,int pos) {
		posicionrecaudacion=pos;
		if(!nombre.equals(personaje[pos])) {
				personaje[pos]=nombre;
				recaudacion[pos]=recaudado;
		}
		else {
			if(nombre.equals(personaje[pos])) {
				recaudacion[pos]=recaudado;
			}
		}
	}
	public boolean agregarCuenta(String nombreCuenta,String password,String nick ,int nivelCuenta, int rp,String region) {
		Cuenta c = new Cuenta(nombreCuenta, password, nick, nivelCuenta, rp, region);
		boolean ingreso = ListaCuenta.insertarCuenta(c);
		return ingreso;
	}
	public boolean agregarPersonaje(String nombre,String rol,int cantidadSkins) {
		Personaje p = new Personaje(nombre,rol,cantidadSkins);
		boolean ingreso = ListaPersonaje.insertarPersonaje(p);
		return ingreso;
	}
	@Override
	public boolean agregarSkins(String nombre, String calidad) {
		Skins s = new Skins(nombre,calidad);
		boolean ingreso = ListaSkins.insertarSkins(s);
		return ingreso;
	}
	public void asociarSkinPersonaje(String nombre,String nombreSkins) {
		Personaje p =ListaPersonaje.buscarNombre(nombre);
		Skins s =ListaSkins.buscarNombre(nombreSkins);
		if (p != null && s !=null) {
			p.getSkinsPersonaje().insertarSkins(s);
		}
	}
	public void asociarSkinCuenta(String nombrecuenta,String nombreSkins) {
		Cuenta c =ListaCuenta.buscarNombre(nombrecuenta);
		Skins s =ListaSkins.buscarNombre(nombreSkins);
		if (c != null && s !=null) {
			c.getSkins().insertarSkins(s);
		}
	}
	public void asociarPersonajeCuenta(String nombrecuenta,String nombrePersonaje) {
		Cuenta c =ListaCuenta.buscarNombre(nombrecuenta);
		Personaje p =ListaPersonaje.buscarNombre(nombrePersonaje);
		if (p != null && p !=null) {
			c.getPersonajes().insertarPersonaje(p);
		}
	}
	public String Obtener() {
		String text ="";
		System.out.println("obtner: ");
		for(int i=0;i<ListaCuenta.getCont();i++) {
			System.out.println();
		}
		return text;
	}
	public void iniciar_sesion() { 
		boolean llave = true;
		while(llave) {
			System.out.println("INICIAR SESION");
			System.out.println("Escriba su nombre");
			System.out.println("Para finalizar el programa introduzca 0");
			Scanner sc = new Scanner(System.in);
			String nombre = sc.nextLine();
			int posicion=clasificar_nombre(nombre);
			if((nombre).equals("0")) {
				llave=false;
				System.out.println("Se a finalizado la operacion");
			}
			else if (posicion==-1) {
				System.out.println("Escriba su contrase�a");
				String contrase�a = sc.nextLine();
				if((contrase�a).equals("ADMIN") || (contrase�a).equals("admin") ) {
					menu_admin();
				}
				else{
					System.out.println("ERROR-Contrase�a invalida");
				}
			}
			else if (posicion==-3) {
				System.out.println("Usuario bloqueado");
			}
			else if (posicion>=0) {
				System.out.println("Escriba su contrase�a");
				String contrase�a = sc.nextLine();
				if((contrase�a).equals(ListaCuenta.getCuentaI(posicion).getPassword())) {
					menu_cliente1();
				}
				else{
					System.out.println("ERROR-Contrase�a invalida");
				}
			}
			else{
				System.out.println("Usuario no existe");
				System.out.println("Desea crar un nuevo Usuario");
				System.out.println("Y/N");
				String clave = sc.nextLine();
				if((clave).equals("y")||(clave).equals("Y")) {
					nuevo_usuario(nombre);
				}
				else if((clave).equals("n")||(clave).equals("N")) {
					/// NO SE HACE NADA
				}
				else{
					System.out.println("ERROR COMANDO NO RECONOCIDO");
				}
				System.out.println("Volviendo al principio de la operacion");
			}
		}
		
	}
	public int clasificar_nombre(String nombreclasificar) {
		for(int i=0;i<ListaCuenta.getCont();i++) {
			if(nombreclasificar.equals(ListaCuenta.getCuentaI(i).getNombreCuenta())) {
				if(ListaCuenta.getCuentaI(i).getNick().equals("bloqueado")) {
					return -3;
				}
			}
		}
		if(nombreclasificar.equals("ADMIN") || nombreclasificar.equals("admin")) {
			return -1;
		}
		for(int i=0;i<ListaCuenta.getCont();i++) {
			if(nombreclasificar.equals(ListaCuenta.getCuentaI(i).getNombreCuenta())) {
				return i;
			}
		}
		return -2;
	}
	public void nuevo_usuario(String nombre){
		Scanner sc = new Scanner(System.in);
		System.out.println("NOMBRE: "+nombre);
		System.out.println("Porfavor indique su contrase�a:");
		String password = sc.nextLine();
		System.out.println("Porfavor indique su nick:");
		String nick = sc.nextLine();
		System.out.println("Porfavor indique su region:");
		String region = sc.nextLine();
		agregarCuenta(nombre,password,nick,0,0,region);
		ListaCuenta.setCont(ListaCuenta.getCont()+1);
	}
	public void menu_cliente1() {
		boolean llave1 =true;
		while(llave1) {
			System.out.println("MENU CLIENTE: ");
			System.out.println("1)Comprar Skin");
			System.out.println("2)Comprar Personaje");
			System.out.println("3)Skins Disponibles: ");
			System.out.println("4)Mostrar Inventario: ");
			System.out.println("5)Recargar RP: ");
			System.out.println("6)Mostar Datos Cuenta: ");
			System.out.println("7)Cambio de contrase�a");
			System.out.println("8)Salir");
			Scanner sc = new Scanner(System.in);
			String seleccion = sc.nextLine();
			if((seleccion).equals("1")) {
				System.out.println("COMPRAR SKIN");
				CompraSkin(seleccion);
			}
			else if((seleccion).equals("2")) {
				System.out.println("COMPRAR PERSONAJE");
				CompraPersonaje(seleccion);
			}
			if((seleccion).equals("3")) {
				System.out.println("SKINS DISPONIBLES");
				SkinDisponibles(seleccion);
			}
			else if((seleccion).equals("4")) {
				System.out.println("INVENTARIO");
				mostrarInventario(seleccion);
			}
			if((seleccion).equals("5")) {
				System.out.println("RECARGA DE RP");
				recargaRP(seleccion);
			}
			else if((seleccion).equals("6")) {
				System.out.println("DATOS DE LA CUENTA");
				DatosCuenta(seleccion);
			}
			else if((seleccion).equals("7")) {
				System.out.println("CAMBIO CONTRASE�A");
				CambioPassword(seleccion);
			}
			else if((seleccion).equals("8")) {
				llave1 = false;
				System.out.println("Saliendo");
			}
			else {
				System.out.println("ERROR-NO SE RECONOCE EL COMMANDO");
			}
		}
	}
	/**
	 * Esdte procedimiento har� la compra de la skin
	 */
	public void CompraSkin(String NombreCuenta1) {
		Cuenta c = ListaCuenta.buscarNombre(NombreCuenta1);
		if(c != null) {
				for(int i=0;i<ListaCuenta.getCont();i++) {
					if (ListaCuenta.getCuentaI(i).getRp() < 975 ) {
							System.out.println("No puede realizar la compra, no tiene suficiente dinero");
						}
					else {
						Scanner sc = new Scanner(System.in);
						String NombreCuenta2 = ListaCuenta.getCuentaI(i).getNombreCuenta();
						System.out.println("Ingrese el nombre del personaje al cual se le comprar� la skin: ");
						String nombrePersonaje1 = sc.nextLine();
						if (!verificarExistenciaPersonaje1(nombrePersonaje1)) {
							System.out.println("El personaje existe");
							System.out.println("Ingrese el nombre de la skin: ");
							String nombreSkin1 =  sc.nextLine();
							if(verificarSkinPersonaje(nombreSkin1)) {
								System.out.println("La Skin existe");
								System.out.println("M�tica (M) -> 3250 RP");
								System.out.println("Definitiva(D) -> 2750 RP");
								System.out.println("Legendaria(L) ->1820 RP");
								System.out.println("�pica (E) -> 1350 RP");
								System.out.println("Normal (N) -> 975 RP");
								System.out.println("Calidad de la skin(ingrese letra): ");
								String calidad = sc.nextLine();
								if(calidad.equalsIgnoreCase("M")) {
									agregarSkins(nombreSkin1,calidad.toUpperCase());
									asociarSkinPersonaje(nombreSkin1,nombreSkin1);
									int rp = ListaCuenta.getCuentaI(i).getRp();
									rp = rp -3250;
									ListaCuenta.getCuentaI(i).setRp(rp);
									int nivel = ListaCuenta.getCuentaI(i).getNivelCuenta();
									nivel = nivel+1;
									ListaCuenta.getCuentaI(i).setNivelCuenta(nivel);
									
								}
								if(calidad.equalsIgnoreCase("D")) {
									agregarSkins(nombreSkin1,calidad.toUpperCase());
									asociarSkinPersonaje(nombreSkin1,nombreSkin1);
									int rp = ListaCuenta.getCuentaI(i).getRp();
									rp = rp -2750;
									ListaCuenta.getCuentaI(i).setRp(rp);
									int nivel = ListaCuenta.getCuentaI(i).getNivelCuenta();
									nivel = nivel+1;
									ListaCuenta.getCuentaI(i).setNivelCuenta(nivel);
								}
								if(calidad.equalsIgnoreCase("L")) {
									agregarSkins(nombreSkin1,calidad.toUpperCase());
									asociarSkinPersonaje(nombreSkin1,nombreSkin1);
									int rp = ListaCuenta.getCuentaI(i).getRp();
									rp = rp -1820;
									ListaCuenta.getCuentaI(i).setRp(rp);
									int nivel = ListaCuenta.getCuentaI(i).getNivelCuenta();
									nivel = nivel+1;
									ListaCuenta.getCuentaI(i).setNivelCuenta(nivel);
								}
								if(calidad.equalsIgnoreCase("E")) {
									agregarSkins(nombreSkin1,calidad.toUpperCase());
									asociarSkinPersonaje(nombreSkin1,nombreSkin1);
									int rp = ListaCuenta.getCuentaI(i).getRp();
									rp = rp -1350;
									ListaCuenta.getCuentaI(i).setRp(rp);
									int nivel = ListaCuenta.getCuentaI(i).getNivelCuenta();
									nivel = nivel+1;
									ListaCuenta.getCuentaI(i).setNivelCuenta(nivel);
								}
								if(calidad.equalsIgnoreCase("N")) {
									agregarSkins(nombreSkin1,calidad.toUpperCase());
									asociarSkinPersonaje(nombreSkin1,nombreSkin1);
									int rp = ListaCuenta.getCuentaI(i).getRp();
									rp = rp -975;
									ListaCuenta.getCuentaI(i).setRp(rp);
									int nivel = ListaCuenta.getCuentaI(i).getNivelCuenta();
									nivel = nivel+1;
									ListaCuenta.getCuentaI(i).setNivelCuenta(nivel);
								}
								else {
									System.out.println("Calidad invalida");
								}
								System.out.println("Realizando la compra...");
								System.out.println("--------COMPRA REALIZADA CON �XITO----------");
								asociarSkinPersonaje(nombrePersonaje1,nombreSkin1);
								asociarSkinCuenta(NombreCuenta1,nombreSkin1);
							}
							else {
								System.out.println("La Skin NO pertenece al Personaje");
								break;
							}
						}
						else {
							System.out.println("El personaje no Existe");
							}
							
					}
				}
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Este procedimiento har� la compra del personaje 
	 */
	public void CompraPersonaje(String NombreCuenta1) {
		Cuenta c = ListaCuenta.buscarNombre(NombreCuenta1);
		if(c != null) {
			for(int i=0;i<ListaCuenta.getCont();i++) {
				if (NombreCuenta1.equals(ListaCuenta.buscarNombre(NombreCuenta1))){
					if (ListaCuenta.getCuentaI(i).getRp() < 975 ) {
						System.out.println("No puede realizar la compra, no tiene suficiente dinero");
					}
					else {
						Scanner sc = new Scanner(System.in);
						String NombreCuenta2 = ListaCuenta.getCuentaI(i).getNombreCuenta();
						System.out.println("Ingrese el nombre del personaje que comprar�: ");
						String nombrePersonaje2 = sc.nextLine();
						if (verificarExistenciaPersonaje1(nombrePersonaje2)) {
							System.out.println("El personaje no Existe");
						}
						else {
							System.out.println("El personaje existe");
							System.out.println("Realizando la compra...");
							asociarPersonajeCuenta(NombreCuenta1,nombrePersonaje2);
							int rp = ListaCuenta.getCuentaI(i).getRp();
							rp = rp -975;
							ListaCuenta.getCuentaI(i).setRp(rp);
							int nivel = ListaCuenta.getCuentaI(i).getNivelCuenta();
							nivel = nivel+1;
							ListaCuenta.getCuentaI(i).setNivelCuenta(nivel);
						
						}
					}
				}
				else {
					System.out.println("No se ha encontrado la cuenta");
					}
			}
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Este procedimiento mostrar� las skins disponibles en el sistema
	 * @param NombreCuenta1
	 */
	public void SkinDisponibles(String NombreCuenta1) {
		Cuenta c = ListaCuenta.buscarNombre(NombreCuenta1);
		if(c != null) {
			for(int i=0;i<ListaCuenta.getCont();i++) {
				if (NombreCuenta1.equals(ListaCuenta.buscarNombre(NombreCuenta1))){
					for(int j=0;j<ListaSkins.getCont();j++) {
						for(int k=0;k < ListaCuenta.getCont();k++) {
							if (ListaSkins.getSkinsI(i).getNombre() .equals((ListaCuenta.getCuentaI(k).getSkins()))) {
								String SkinsBorrarPrint = ListaSkins.getSkinsI(i).getNombre();
								SkinsBorrarPrint = null;
							}
						}
					}
					for(int j=0;j<ListaSkins.getCont();j++) {
						System.out.println(" "+ListaSkins.getSkinsI(i).getNombre()+" ");
					}
				}
				else {
					System.out.println("No se ha encontrado la cuenta");
				}
			}
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Este Procedimiento mostrar� el inventario de la cuenta
	 */
	private void mostrarInventario(String NombreCuenta1) {
		Cuenta c = ListaCuenta.buscarNombre(NombreCuenta1);
		if(c != null) {
			for(int i=0;i<ListaCuenta.getCont();i++) {
				if (NombreCuenta1.equals(ListaCuenta.buscarNombre(NombreCuenta1))){
					System.out.println("Personajes: "+ ListaCuenta.getCuentaI(i).getPersonajes());	
					System.out.println("Skins: "+ListaCuenta.getCuentaI(i).getSkins());	
				}
				else {
					System.out.println("No se encontro la cuenta");	
				}
			}
		}
		else {
			System.out.println("Volviendo al Principio...");
		}
		
		// TODO Auto-generated method stub
	}
	/**
	 * Este procedimiento  Recargar� rp a la cuenta
	 * @param NombreCuenta1
	 */
	private void recargaRP(String NombreCuenta1) {
		Cuenta c = ListaCuenta.buscarNombre(NombreCuenta1);
		if(c != null) {
			for(int i=0;i<ListaCuenta.getCont();i++) {
				if (NombreCuenta1.equals(ListaCuenta.buscarNombre(NombreCuenta1))){
					Scanner sc = new Scanner(System.in);
					System.out.println("Ingrese la cantidad de RP que desea agregar: ");
					int RPingresado = sc.nextInt();
					System.out.println("Se ingreso el RP deseado");
					int Rp = ListaCuenta.getCuentaI(i).getRp();
					Rp = Rp + RPingresado;
					ListaCuenta.getCuentaI(i).setRp(Rp);
				}
				else {
					System.out.println("No se ha encontrado la cuenta");
					}
				}
			}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Este procedimiento Desplegar� los datos de la cuenta ingresada
	 * @param NombreCuenta1
	 */
	private void DatosCuenta(String NombreCuenta1) {
		Cuenta c = ListaCuenta.buscarNombre(NombreCuenta1);
		if(c != null) {
			for(int i=0;i<ListaCuenta.getCont();) {
				if (NombreCuenta1.equals(ListaCuenta.buscarNombre(NombreCuenta1))){
				System.out.println("Nombre Cuenta: "+ ListaCuenta.buscarNombre(NombreCuenta1).getNombreCuenta());
				System.out.println("Nick de la Cuenta: "+ListaCuenta.buscarNombre(NombreCuenta1).getNick());
				String contrase�aPrint = ListaCuenta.buscarNombre(NombreCuenta1).getPassword();
				System.out.println("Contrase�a: "+"******"+contrase�aPrint.substring(contrase�aPrint.length()-3,contrase�aPrint.length()));
				break;
				}
				else {
					System.out.println("No se ha encontrado la cuenta");
				}
			}
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Este procedimiento hara el cambio de contrase�a en la cuenta
	 * @param NombreCuenta1
	 */
	private void CambioPassword(String NombreCuenta1) {
		Cuenta c = ListaCuenta.buscarNombre(NombreCuenta1);
		if(c != null) {
			for(int i=0;i<ListaCuenta.getCont();i++) {
				if (NombreCuenta1.equals(ListaCuenta.buscarNombre(NombreCuenta1))){
					Scanner sc = new Scanner(System.in);
					System.out.println("Ingrese la contrase�a antigua: ");
					String contrase�aAntigua = sc.nextLine();
					if(contrase�aAntigua.equals(ListaCuenta.getCuentaI(i).getPassword())) {
						System.out.println("La contrase�a es correcta");
						System.out.println("Ingrese la contrase�a nueva: ");
						String contrase�aNueva = sc.nextLine();
						System.out.println("Ingrese otra vez la contrase�a nueva: ");
						String contrase�aNueva1 = sc.nextLine();
						if(contrase�aNueva.equals(contrase�aNueva1)) {
							System.out.println("Las contrase�as coinciden");
							System.out.println("Se cambi� su contrase�a");
							String password= contrase�aNueva;
							agregarCuenta(ListaCuenta.getCuentaI(i).getNombreCuenta(),password,ListaCuenta.getCuentaI(i).getNick(),0,0,ListaCuenta.getCuentaI(i).getRegion());
							ListaCuenta.getCuentaI(i).setPassword(contrase�aNueva1);;
						}
					}
					else {
						System.out.println("La contrase�a es incorrecta");	
						}
				}
				else {
					System.out.println("No se ha encontrado la cuenta");
					}
			}
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Esta funcion verificar� si la skin ingresada pertenece al personaje
	 * @param nombre
	 * @return true si pertenece al personaje y false si no pertenece al personaje
	 */
	public boolean verificarSkinPersonaje(String nombre) {
			Skins verificarSkin = ListaSkins.buscarNombre(nombre);
			if(verificarSkin == null) {
				return true;
			}
			else {
				return false;
			}
	}
	/**
	 * Esta funcion verificar� si el personaje ingresado existe en el sistema
	 * @param nombre
	 * @return true si el personaje existe y false si el personaje no existe
	 */
	public boolean verificarExistenciaPersonaje1(String nombre) {
		Personaje nuevo1 = ListaPersonaje.buscarNombre(nombre);
		if(nuevo1 == null) {
			return true;
		}
		else {
			return false;
		}
	}
	/**
	 * Esta funcion verificar� si la skin ingresada existe en el sistema
	 * @param nombre
	 * @returntrue si la skin existe y false si la skin no existe
	 */
	public boolean verificarExistenciaSkin1(String nombre) {
		Skins nuevoskin = ListaSkins.buscarNombre(nombre);
		if(nuevoskin==null) {
			return true;
		}
		else {
			return false;
		}
	}
	public void menu_cliente() {
		boolean llave =true;
		while(llave) {
			System.out.println("MENU CLIENTE: ");
			System.out.println("1)Comprar skin:");
			System.out.println("2)bloquear");
			System.out.println("3)salir");
			Scanner sc = new Scanner(System.in);
			String seleccion = sc.nextLine();
			if((seleccion).equals("1")) {
				System.out.println("menu1");
				//falta venta por region y por rol esperar a cristian
			}
			else if((seleccion).equals("2")) {
				bloquear();
			}
			else if((seleccion).equals("3")) {
				llave=false;
				System.out.println("Saliendo");
			}
			else {
				System.out.println("ERROR-NO SE RECONOCE EL COMMANDO");
			}
		}
	}
	
	public void menu_admin() {
		boolean llave =true;
		while(llave) {
			System.out.println("MENU ADMIN: ");
			System.out.println("1)Despliegue de recaudaciones:");
			System.out.println("2)Cantidad de personajes por rol");
			System.out.println("3)Agregar Personaje");
			System.out.println("4)Agregar Skin");
			System.out.println("5)Bloquear a un jugador");
			System.out.println("6)Desplegar Cuentas");
			System.out.println("7)Salir");
			Scanner sc = new Scanner(System.in);
			String seleccion = sc.nextLine();
			if((seleccion).equals("1")) {
				desplegarRecaudacion();
				//falta venta por region y por rol esperar a cristian
			}
			else if((seleccion).equals("2")) {
				desplegarPersonajeRol();
			}
			else if((seleccion).equals("3")) {
				agregarPersonajeNuevo();
			}
			else if((seleccion).equals("4")) {
				agregarSkin();
			}
			else if((seleccion).equals("5")) {
				bloquear();
			}
			else if((seleccion).equals("6")) {
				cuentasOrdenadas();
			}
			else if((seleccion).equals("7")) {
				llave=false;
				System.out.println("Saliendo");
			}
			else {
				System.out.println("ERROR-NO SE RECONOCE EL COMMANDO");
			}
		}
	}
	public void desplegarRecaudacion() {
		for(int i=0;i<posicionrecaudacion+1;i++) {
			System.out.println("Personaje: "+personaje[i]+" Recaudacion: "+recaudacion[i]);
		}
	}
	public void desplegarPersonajeRol() {
		System.out.println("PERSOANJES POR ROL EXISTENTE");
		for(int i=0;i<ListaPersonaje.getCont();i++) {
			if(ListaPersonaje.getPersonajeI(i).getRol().equals("SUP")) {
				System.out.println("         SUP");
				System.out.println(i+1+")"+"Personaje: "+ListaPersonaje.getPersonajeI(i).getNombre()+" Rol: "+ListaPersonaje.getPersonajeI(i).getRol());
			}
			if(ListaPersonaje.getPersonajeI(i).getRol().equals("ADC")) {
				System.out.println("         ADC");
				System.out.println(i+1+")"+"Personaje: "+ListaPersonaje.getPersonajeI(i).getNombre()+" Rol: "+ListaPersonaje.getPersonajeI(i).getRol());
			}
			if(ListaPersonaje.getPersonajeI(i).getRol().equals("TOP")) {
				System.out.println("         TOP");
				System.out.println(i+1+")"+"Personaje: "+ListaPersonaje.getPersonajeI(i).getNombre()+" Rol: "+ListaPersonaje.getPersonajeI(i).getRol());
			}
			if(ListaPersonaje.getPersonajeI(i).getRol().equals("MID")) {
				System.out.println("         MID");
				System.out.println(i+1+")"+"Personaje: "+ListaPersonaje.getPersonajeI(i).getNombre()+" Rol: "+ListaPersonaje.getPersonajeI(i).getRol());
			}
			if(ListaPersonaje.getPersonajeI(i).getRol().equals("JG")) {
				System.out.println("         JG");
				System.out.println(i+1+")"+"Personaje: "+ListaPersonaje.getPersonajeI(i).getNombre()+" Rol: "+ListaPersonaje.getPersonajeI(i).getRol());
			}
		}
	}
	public void agregarPersonajeNuevo() {
		System.out.println("AGREGAR PERSONAJE AL JUEGO");
		Scanner sc = new Scanner(System.in);
		System.out.println("Nombre del personaje: ");
		String nombre = sc.nextLine();
		if(!verificarExistenciaPersonaje(nombre)) {
			System.out.println("Rol del personaje: ");
			String rol = sc.nextLine();
			System.out.println("cantidad de skins: ");
			String cantidadt = sc.nextLine();
			int cantidad=Integer.parseInt(cantidadt);
			agregarPersonaje(nombre.toLowerCase(),rol.toUpperCase(),cantidad);
			for(int i=0;i<cantidad;i++) {
				System.out.println("Nombre de las skins");
				String nombreskins = sc.nextLine();
				asociarSkinPersonaje(nombre,nombreskins);
			}
		}
		else {
			System.out.println("personaje ya existe");
		}
	}
	public boolean verificarExistenciaPersonaje(String nombre) {
		Personaje nuevo = ListaPersonaje.buscarNombre(nombre);
		if(nuevo==null) {
			return false;
		}
		else {
			return true;
		}
	}
	public boolean verificarExistenciaSkin(String nombre) {
		Skins nuevoskin = ListaSkins.buscarNombre(nombre);
		if(nuevoskin==null) {
			return false;
		}
		else {
			return true;
		}
	}
	public void agregarSkin() {
		System.out.println("AGREGAR SKIN AL JUEGO");
		Scanner sc = new Scanner(System.in);
		System.out.println("Nombre del personaje: ");
		String nombre = sc.nextLine();
		if(verificarExistenciaPersonaje(nombre)) {
			System.out.println("Nombre de la skin: ");
			String skin = sc.nextLine();
			if(!verificarExistenciaSkin(skin)) {
				System.out.println("M�tica (M) -> 3250 RP");
				System.out.println("Definitiva(D) -> 2750 RP");
				System.out.println("Legendaria(L) ->1820 RP");
				System.out.println("�pica (E) -> 1350 RP");
				System.out.println("Normal (N) -> 975 RP");
				System.out.println("Calidad de la skin(ingrese letra): ");
				String calidad = sc.nextLine();
				if(calidad.equalsIgnoreCase("M")) {
					agregarSkins(skin,calidad.toUpperCase());
					asociarSkinPersonaje(nombre,skin);
				}
				if(calidad.equalsIgnoreCase("D")) {
					agregarSkins(skin,calidad.toUpperCase());
					asociarSkinPersonaje(nombre,skin);
				}
				if(calidad.equalsIgnoreCase("L")) {
					agregarSkins(skin,calidad.toUpperCase());
					asociarSkinPersonaje(nombre,skin);
				}
				if(calidad.equalsIgnoreCase("E")) {
					agregarSkins(skin,calidad.toUpperCase());
					asociarSkinPersonaje(nombre,skin);
				}
				if(calidad.equalsIgnoreCase("N")) {
					agregarSkins(skin,calidad.toUpperCase());
					asociarSkinPersonaje(nombre,skin);
				}
				else {
					System.out.println("Calidad invalida");
				}
			}
			else {
				System.out.println("Skin ya existe");
			}
		}
		else {
			System.out.println("Personaje no existe");
		}
	}
	public void bloquear() {
		System.out.println("BLOQUEAR JUGADOR");
		Scanner sc = new Scanner(System.in);
		System.out.println("Nombre de la cuenta: ");
		String nombre = sc.nextLine();
		Cuenta bloquear = ListaCuenta.buscarNombre(nombre);
		bloquear.setNick("bloqueado");
	}
	public void cuentasOrdenadas() {
		System.out.println("CUENTAS ORDENADAS");
		ListaCuenta.ordenar();
		for(int i=0;i<ListaCuenta.getCont();i++) {
			System.out.println("Nick Cuenta: "+ListaCuenta.getCuentaI(i).getNick()+" Nivel Cuenta:"+ListaCuenta.getCuentaI(i).getNivelCuenta());
		}
	}
	public String StringPersonaje() {
		String salida = "";
		for(int i=0;i<ListaPersonaje.getCont();i++) {
			salida += ListaPersonaje.getPersonajeI(i).getNombre()+","+ListaPersonaje.getPersonajeI(i).getRol()+","+ListaPersonaje.getPersonajeI(i).getCantidadSkins()+"\n";
			/*
			for(int j=0;j<ListaPersonaje.getPersonajeI(i).getCantidadSkins();j++) {
				salida += ListaPersonaje.getPersonajeI(i).getSkinsPersonaje().getSkinsI(j).getNombre()+","+ListaPersonaje.getPersonajeI(i).getSkinsPersonaje().getSkinsI(j).getCalidad();
			}
			*/
		}
		return salida.trim();
	}
	public String StringCuenta() {
		String salida = "";
		for(int i=0;i<ListaCuenta.getCont();i++) {
			salida += ListaCuenta.getCuentaI(i).getNombreCuenta()+","+ListaCuenta.getCuentaI(i).getPassword()+","+ListaCuenta.getCuentaI(i).getNick()+","+ListaCuenta.getCuentaI(i).getNivelCuenta()+","+ListaCuenta.getCuentaI(i).getRp()+","+ListaCuenta.getCuentaI(i).getPersonajes().getCont()+"\n";
			
		}
		return salida.trim();
	}
	public String StringEstadistica() {
		String salida = "";
		for(int i=0;i<posicionrecaudacion+1;i++) {
			salida += personaje[i]+","+recaudacion[i]+"\n";
		}
		return salida.trim();
	}
	
}
